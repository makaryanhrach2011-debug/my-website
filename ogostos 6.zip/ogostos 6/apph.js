// const buttons = document.querySelectorAll('.code-btn');
// const codeDisplay = document.getElementById('code-display');

// const codes = {
//   html: `<!DOCTYPE html>
// <html>
//   <head>
//     <title>My HTML</title>
//   </head>
//   <body>
//     <h1>Բարի գալուստ HTML</h1>
//   </body>
// </html>`,
  
//   css: `body {
//   background-color: #f0f0f0;
//   font-family: Arial, sans-serif;
// }

// h1 {
//   color: #333;
//   text-align: center;
// }`,
  
//   js: `console.log('Բարի գալուստ JavaScript');\n
// function greet() {
//   alert('Hello from JS!');
// }
// greet();`
// };

// buttons.forEach(btn => {
//   btn.addEventListener('click', () => {
//     const codeType = btn.getAttribute('data-code');
//     codeDisplay.textContent = codes[codeType] || '';
//   });
// });